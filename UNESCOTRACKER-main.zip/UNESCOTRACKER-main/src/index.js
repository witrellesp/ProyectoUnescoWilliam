import './globe.css';

export { default } from './globe';